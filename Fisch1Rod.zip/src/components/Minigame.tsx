import { useEffect, useRef, useState } from "react";
import type { Fish } from "../data/fishData";

interface Props {
  fish: Fish;
  tensionBonus: number;
  onResult: (success: boolean) => void;
}

const BAR_HEIGHT = 280;
const PLAYER_HEIGHT = 28;

export function Minigame({ fish, tensionBonus, onResult }: Props) {
  const [, force] = useState(0);

  // Live game state stored in refs (avoid stale closures and double renders)
  const playerPosRef = useRef(BAR_HEIGHT / 2);
  const playerVelRef = useRef(0);
  const zonePosRef = useRef(BAR_HEIGHT / 2 - 40);
  const zoneVelRef = useRef(fish.difficulty.speed);
  const progressRef = useRef(50);
  const escapeTimerRef = useRef(0);
  const lastTimeRef = useRef(performance.now());
  const rafRef = useRef<number | null>(null);
  const endedRef = useRef(false);
  const pressedRef = useRef(false);

  const zoneHeightPct = fish.difficulty.zoneSize + tensionBonus;
  const zoneHeightPx = (zoneHeightPct / 100) * BAR_HEIGHT;

  useEffect(() => {
    const down = (e: Event) => {
      e.preventDefault();
      pressedRef.current = true;
    };
    const up = () => {
      pressedRef.current = false;
    };
    window.addEventListener("mousedown", down);
    window.addEventListener("mouseup", up);
    window.addEventListener("touchstart", down, { passive: false });
    window.addEventListener("touchend", up);
    window.addEventListener("touchcancel", up);
    return () => {
      window.removeEventListener("mousedown", down);
      window.removeEventListener("mouseup", up);
      window.removeEventListener("touchstart", down);
      window.removeEventListener("touchend", up);
      window.removeEventListener("touchcancel", up);
    };
  }, []);

  useEffect(() => {
    const loop = (now: number) => {
      if (endedRef.current) return;
      const dt = Math.min(50, now - lastTimeRef.current);
      lastTimeRef.current = now;

      // ===== Player physics =====
      const gravity = 0.5;
      const lift = -1.2;
      if (pressedRef.current) playerVelRef.current += lift;
      playerVelRef.current += gravity;
      playerVelRef.current *= 0.9;
      playerPosRef.current += playerVelRef.current;

      if (playerPosRef.current < 0) {
        playerPosRef.current = 0;
        playerVelRef.current = 0;
      }
      if (playerPosRef.current > BAR_HEIGHT - PLAYER_HEIGHT) {
        playerPosRef.current = BAR_HEIGHT - PLAYER_HEIGHT;
        playerVelRef.current = 0;
      }

      // ===== Zone physics =====
      zonePosRef.current += zoneVelRef.current;
      if (zonePosRef.current < 0) {
        zonePosRef.current = 0;
        zoneVelRef.current *= -1;
      } else if (zonePosRef.current > BAR_HEIGHT - zoneHeightPx) {
        zonePosRef.current = BAR_HEIGHT - zoneHeightPx;
        zoneVelRef.current *= -1;
      }

      // ===== Collision / progress =====
      const overlap =
        playerPosRef.current + PLAYER_HEIGHT > zonePosRef.current &&
        playerPosRef.current < zonePosRef.current + zoneHeightPx;

      if (overlap) {
        progressRef.current += 0.08 * dt;
      } else {
        progressRef.current -= 0.04 * dt;
      }
      if (progressRef.current < 0) progressRef.current = 0;
      if (progressRef.current > 100) progressRef.current = 100;

      if (progressRef.current <= 0) {
        escapeTimerRef.current += dt;
      } else {
        escapeTimerRef.current = 0;
      }

      // Render
      force((n) => (n + 1) % 1000000);

      // ===== End conditions =====
      if (progressRef.current >= 100) {
        endedRef.current = true;
        onResult(true);
        return;
      }
      if (escapeTimerRef.current >= 1200) {
        endedRef.current = true;
        onResult(false);
        return;
      }

      rafRef.current = requestAnimationFrame(loop);
    };

    lastTimeRef.current = performance.now();
    rafRef.current = requestAnimationFrame(loop);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      endedRef.current = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center select-none cursor-pointer"
      style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)" }}
    >
      <div className="flex flex-col items-center gap-6 animate-pop">
        <div className="text-center">
          <div className="text-5xl mb-2 animate-wiggle inline-block">{fish.emoji}</div>
          <h3 className="text-xl font-bold text-white">
            Удерживайте 🎣 в зелёной зоне!
          </h3>
          <p className="text-sm text-white/70 mt-1">
            Зажмите экран / ЛКМ чтобы поднять крючок
          </p>
        </div>

        <div className="flex items-center gap-6">
          {/* Bar */}
          <div
            className="relative rounded-2xl overflow-hidden border-4"
            style={{
              width: 56,
              height: BAR_HEIGHT,
              borderColor: "rgba(255,255,255,0.85)",
              background:
                "linear-gradient(180deg, #0f172a 0%, #1e293b 50%, #0c1f3d 100%)",
              boxShadow:
                "0 20px 60px -10px rgba(0,0,0,0.6), inset 0 0 20px rgba(0,0,0,0.5)",
            }}
          >
            {/* Zone */}
            <div
              className="absolute left-0 right-0 rounded-md"
              style={{
                top: zonePosRef.current,
                height: zoneHeightPx,
                background:
                  "linear-gradient(180deg, rgba(74,222,128,0.85), rgba(34,197,94,0.85))",
                boxShadow: "0 0 16px rgba(34,197,94,0.7)",
              }}
            />
            {/* Player */}
            <div
              className="absolute left-1 right-1 rounded-md flex items-center justify-center text-base font-bold"
              style={{
                top: playerPosRef.current,
                height: PLAYER_HEIGHT,
                background: "linear-gradient(180deg, #fde047, #facc15)",
                boxShadow: "0 0 12px rgba(250,204,21,0.8)",
                color: "#422006",
              }}
            >
              🎣
            </div>
          </div>

          {/* Progress vertical */}
          <div
            className="relative rounded-2xl overflow-hidden border-2"
            style={{
              width: 28,
              height: BAR_HEIGHT,
              borderColor: "rgba(255,255,255,0.6)",
              background: "rgba(0,0,0,0.4)",
            }}
          >
            <div
              className="absolute left-0 right-0 bottom-0 rounded-md"
              style={{
                height: `${progressRef.current}%`,
                background: "linear-gradient(0deg, #f97316, #fbbf24, #4ade80)",
                boxShadow: "0 0 14px rgba(251,191,36,0.7)",
              }}
            />
          </div>
        </div>

        <div className="text-white/80 text-sm tabular-nums">
          Прогресс: {Math.round(progressRef.current)}%
        </div>
      </div>
    </div>
  );
}
