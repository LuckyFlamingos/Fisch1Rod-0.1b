import { cn } from "../utils/cn";

export type Theme = "light" | "dark" | "ocean";

interface Props {
  theme: Theme;
  setTheme: (t: Theme) => void;
}

const options: { id: Theme; icon: string; label: string }[] = [
  { id: "light", icon: "☀️", label: "Свет" },
  { id: "dark", icon: "🌙", label: "Ночь" },
  { id: "ocean", icon: "🌊", label: "Океан" },
];

export function ThemeSwitcher({ theme, setTheme }: Props) {
  return (
    <div
      className="glass inline-flex p-1 rounded-full gap-1"
      style={{ boxShadow: "var(--shadow)" }}
    >
      {options.map((o) => (
        <button
          key={o.id}
          onClick={() => setTheme(o.id)}
          className={cn(
            "px-3 py-1.5 rounded-full text-sm font-semibold transition-all flex items-center gap-1.5 btn-press",
            theme === o.id ? "scale-105" : "opacity-60 hover:opacity-100"
          )}
          style={
            theme === o.id
              ? {
                  background: "linear-gradient(135deg, var(--accent), var(--accent-2))",
                  color: "white",
                  boxShadow: "0 6px 18px -6px var(--accent)",
                }
              : { color: "var(--text)" }
          }
          title={o.label}
        >
          <span>{o.icon}</span>
          <span className="hidden sm:inline">{o.label}</span>
        </button>
      ))}
    </div>
  );
}
