import { useEffect } from "react";
import type { ReactNode } from "react";

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  icon?: string;
  children: ReactNode;
}

export function Modal({ open, onClose, title, icon, children }: ModalProps) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-[pop_.2s_ease-out]"
      style={{ background: "rgba(0,0,0,0.55)", backdropFilter: "blur(6px)" }}
      onClick={onClose}
    >
      <div
        className="glass rounded-2xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden animate-pop"
        style={{
          background: "var(--surface-strong)",
          color: "var(--text)",
          boxShadow: "var(--shadow)",
          border: "1px solid var(--border)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className="flex items-center justify-between px-6 py-4 border-b"
          style={{ borderColor: "var(--border)" }}
        >
          <h2 className="text-xl font-bold flex items-center gap-2">
            {icon && <span className="text-2xl">{icon}</span>}
            {title}
          </h2>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center text-xl transition-colors btn-press"
            style={{ background: "var(--surface-soft)", color: "var(--text-muted)" }}
          >
            ✕
          </button>
        </div>
        <div className="p-6 overflow-y-auto scrollbar-clean flex-1">{children}</div>
      </div>
    </div>
  );
}
