import { useEffect, useMemo, useRef, useState } from "react";
import {
  fishData,
  rarityChances,
  rarityLabels,
  rarityOrder,
  changelogData,
  mutations,
  rollMutation,
  type Fish,
  type Rarity,
  type Mutation,
} from "./data/fishData";
import { ThemeSwitcher, type Theme } from "./components/ThemeSwitcher";
import { Modal } from "./components/Modal";
import { Minigame } from "./components/Minigame";
import { cn } from "./utils/cn";

type GameState =
  | "idle"
  | "casting"
  | "waiting"
  | "reeling"
  | "fighting"
  | "success"
  | "failure";

const tensionUpgradeCosts = [50, 150, 300, 600, 1000];
const TENSION_UPGRADE_BONUS = 2;
const questTargets = fishData.filter((f) =>
  ["common", "uncommon", "rare"].includes(f.rarity)
);

interface Task {
  targetName: string;
  requiredCount: number;
  currentCount: number;
  reward: number;
}

function generateTask(): Task {
  const target = questTargets[Math.floor(Math.random() * questTargets.length)];
  let req = 0;
  switch (target.rarity) {
    case "common": req = Math.floor(Math.random() * 4) + 5; break;
    case "uncommon": req = Math.floor(Math.random() * 3) + 3; break;
    case "rare": req = Math.floor(Math.random() * 2) + 1; break;
  }
  const reward =
    Math.ceil(req * (target.value > 0 ? target.value : 1) * 1.5) + req * 5;
  return { targetName: target.name, requiredCount: req, currentCount: 0, reward };
}

function determineCatch(): Fish {
  const rand = Math.random() * 100;
  let cum = 0;
  for (const rarity in rarityChances) {
    cum += rarityChances[rarity as Rarity];
    if (rand < cum) {
      const subset = fishData.filter((f) => f.rarity === rarity);
      return subset[Math.floor(Math.random() * subset.length)];
    }
  }
  return fishData[0];
}

/** inventory key helpers */
function invKey(fishName: string, mutation: Mutation | null): string {
  return mutation ? `${fishName}|${mutation.id}` : fishName;
}
function parseInvKey(key: string): { name: string; mutation: Mutation | null } {
  const parts = key.split("|");
  const name = parts[0];
  const mutation = parts[1] ? mutations.find((m) => m.id === parts[1]) ?? null : null;
  return { name, mutation };
}

function loadState() {
  try {
    const raw = localStorage.getItem("fisch2-save");
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export default function App() {
  const saved = useMemo(() => loadState(), []);

  const [theme, setTheme] = useState<Theme>(() => {
    return (localStorage.getItem("fisch-theme") as Theme) || "ocean";
  });
  useEffect(() => {
    localStorage.setItem("fisch-theme", theme);
  }, [theme]);

  const [showSplash, setShowSplash] = useState(true);
  const [gameState, setGameState] = useState<GameState>("idle");
  const [statusText, setStatusText] = useState("Готов к рыбалке!");
  const [fishDisplay, setFishDisplay] = useState("🌊");
  const [actionText, setActionText] = useState("Забросить удочку");
  const [hookedFish, setHookedFish] = useState<Fish | null>(null);
  const [hookedMutation, setHookedMutation] = useState<Mutation | null>(null);
  const [reelProgress, setReelProgress] = useState(0);
  const [showReelBar, setShowReelBar] = useState(false);

  const [coins, setCoins] = useState<number>(saved?.coins ?? 0);
  const [inventory, setInventory] = useState<Record<string, number>>(
    saved?.inventory ?? {}
  );
  const [caughtFish, setCaughtFish] = useState<Set<string>>(
    new Set(saved?.caught ?? [])
  );
  const [totalCaught, setTotalCaught] = useState<number>(saved?.totalCaught ?? 0);
  const [tensionLevel, setTensionLevel] = useState<number>(saved?.tensionLevel ?? 0);
  const [task, setTask] = useState<Task>(() => saved?.task ?? generateTask());

  const [showShop, setShowShop] = useState(false);
  const [showInventory, setShowInventory] = useState(false);
  const [showTasks, setShowTasks] = useState(false);
  const [showPedia, setShowPedia] = useState(false);
  const [showMutations, setShowMutations] = useState(false);
  const [showChangelog, setShowChangelog] = useState(false);
  const [toast, setToast] = useState<{ msg: string; kind: "success" | "info" | "fail" } | null>(null);

  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const reelStartRef = useRef<number>(0);
  const reelRafRef = useRef<number | null>(null);

  // ===== SAVE =====
  useEffect(() => {
    localStorage.setItem(
      "fisch2-save",
      JSON.stringify({
        coins,
        inventory,
        caught: Array.from(caughtFish),
        totalCaught,
        tensionLevel,
        task,
      })
    );
  }, [coins, inventory, caughtFish, totalCaught, tensionLevel, task]);

  // Toast auto-hide
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2500);
    return () => clearTimeout(t);
  }, [toast]);

  const totalUniqueFishCount = useMemo(() => fishData.length, []);
  const uniqueCaughtCount = useMemo(() => {
    return Array.from(caughtFish).filter((n) =>
      fishData.some((f) => f.name === n)
    ).length;
  }, [caughtFish]);

  const inventoryTotalValue = useMemo(() => {
    let v = 0;
    for (const key in inventory) {
      const { name, mutation } = parseInvKey(key);
      const fish = fishData.find((f) => f.name === name);
      if (fish) v += (mutation ? fish.value * mutation.multiplier : fish.value) * inventory[key];
    }
    return v;
  }, [inventory]);

  // ===== Game flow =====
  function handleAction() {
    if (gameState === "idle" || gameState === "success" || gameState === "failure") {
      castLine();
    } else if (gameState === "reeling") {
      hookFishAndStart();
    }
  }

  function castLine() {
    setGameState("casting");
    setStatusText("Заброс удочки...");
    setFishDisplay("🎣");
    setHookedFish(null);
    setHookedMutation(null);
    setShowReelBar(false);
    setReelProgress(0);

    timeoutRef.current = setTimeout(() => {
      setGameState("waiting");
      setStatusText("Ждём поклёвки...");
      setFishDisplay("🌊");
      const waitTime = Math.random() * 4000 + 2000;
      timeoutRef.current = setTimeout(fishOnLine, waitTime);
    }, 900);
  }

  function fishOnLine() {
    const newFish = determineCatch();
    const mut = rollMutation();
    setHookedFish(newFish);
    setHookedMutation(mut);
    setGameState("reeling");
    setStatusText("Клюёт! Подсекай!");
    setFishDisplay("❗");
    setActionText("Подсечь!");
    setShowReelBar(true);

    const reelTime = 1800;
    reelStartRef.current = performance.now();
    const tick = () => {
      const elapsed = performance.now() - reelStartRef.current;
      const pct = Math.min(100, (elapsed / reelTime) * 100);
      setReelProgress(pct);
      if (pct >= 100) {
        handleMinigameEnd(false);
        return;
      }
      reelRafRef.current = requestAnimationFrame(tick);
    };
    reelRafRef.current = requestAnimationFrame(tick);
  }

  function hookFishAndStart() {
    if (reelRafRef.current) cancelAnimationFrame(reelRafRef.current);
    setShowReelBar(false);
    setGameState("fighting");
  }

  function handleMinigameEnd(success: boolean) {
    if (reelRafRef.current) cancelAnimationFrame(reelRafRef.current);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);

    if (success && hookedFish) {
      const fish = hookedFish;
      const mut = hookedMutation;
      const key = invKey(fish.name, mut);

      setCaughtFish((prev) => new Set(prev).add(fish.name));
      setTotalCaught((c) => c + 1);
      setInventory((inv) => ({ ...inv, [key]: (inv[key] || 0) + 1 }));

      setTask((t) => {
        if (fish.name === t.targetName && t.currentCount < t.requiredCount) {
          return { ...t, currentCount: t.currentCount + 1 };
        }
        return t;
      });

      const mutText = mut ? ` [${mut.emoji} ${mut.name} ×${mut.multiplier}]` : "";
      const finalValue = mut ? fish.value * mut.multiplier : fish.value;
      setStatusText(`Поймана ${fish.name}!${mutText}`);
      setFishDisplay(fish.emoji);
      setActionText("Закинуть снова");
      setGameState("success");
      setToast({
        msg: `${fish.name}${mutText} (+${finalValue}💰)`,
        kind: "success",
      });
    } else {
      setStatusText("Сорвалась! Рыба ушла...");
      setFishDisplay("💦");
      setActionText("Попробовать снова");
      setGameState("failure");
      setToast({ msg: "Рыба сорвалась с крючка", kind: "fail" });
    }
  }

  // shop
  const tensionMaxLevel = tensionUpgradeCosts.length;
  const tensionCost = tensionLevel < tensionMaxLevel ? tensionUpgradeCosts[tensionLevel] : 0;
  function buyTension() {
    if (tensionLevel >= tensionMaxLevel) return;
    if (coins < tensionCost) return;
    setCoins((c) => c - tensionCost);
    setTensionLevel((l) => l + 1);
    setToast({ msg: "Леска улучшена! +зона", kind: "success" });
  }

  // inventory selling
  function sellOne(key: string) {
    const { name, mutation } = parseInvKey(key);
    const fish = fishData.find((f) => f.name === name);
    if (!fish) return;
    const val = mutation ? fish.value * mutation.multiplier : fish.value;
    setInventory((inv) => {
      const next = { ...inv };
      next[key] -= 1;
      if (next[key] <= 0) delete next[key];
      return next;
    });
    setCoins((c) => c + val);
  }
  function sellAll() {
    setCoins((c) => c + inventoryTotalValue);
    setInventory({});
    setToast({ msg: `Продано на ${inventoryTotalValue} 💰`, kind: "success" });
  }

  function claimTaskReward() {
    if (task.currentCount < task.requiredCount) return;
    setCoins((c) => c + task.reward);
    setToast({ msg: `Награда +${task.reward} 💰`, kind: "success" });
    setTask(generateTask());
  }

  // ===== Determine mutation display on catch =====
  const mutationDisplay = hookedMutation;

  // ============ UI ============
  return (
    <div
      className={cn("min-h-screen w-full transition-colors duration-500", `theme-${theme}`)}
      style={{ background: "var(--bg-grad)", color: "var(--text)" }}
    >
      {/* Decorative blobs */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full opacity-30 blur-3xl" style={{ background: "var(--accent)" }} />
        <div className="absolute top-1/2 -right-40 w-[28rem] h-[28rem] rounded-full opacity-20 blur-3xl" style={{ background: "var(--accent-2)" }} />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
        {/* Header */}
        <header className="flex flex-wrap items-center justify-between gap-3 mb-6">
          <div className="flex items-center gap-3">
            <div className="text-4xl animate-float">🎣</div>
            <div>
              <h1
                className="text-2xl sm:text-3xl font-black tracking-tight"
                style={{
                  backgroundImage: "linear-gradient(135deg, var(--accent), var(--accent-2))",
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  color: "transparent",
                }}
              >
                Fisch 2 Rod
              </h1>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                55 видов · мутации · {fishData.filter((f) => f.rarity === "mythic").length} мифических
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="glass px-4 py-2 rounded-full font-bold flex items-center gap-2" style={{ color: "var(--text)", boxShadow: "var(--shadow)" }}>
              <span className="text-xl">💰</span>
              <span className="tabular-nums">{coins}</span>
            </div>
            <ThemeSwitcher theme={theme} setTheme={setTheme} />
          </div>
        </header>

        {/* Main game card */}
        <main className="glass rounded-3xl p-5 sm:p-8 mb-6" style={{ boxShadow: "var(--shadow)" }}>
          {/* Fishing scene */}
          <div className="water-anim rounded-2xl p-6 sm:p-10 mb-6 text-center relative min-h-[260px] flex flex-col items-center justify-center">
            {gameState === "waiting" && (
              <>
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border-2 border-white/60 animate-ripple" />
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border-2 border-white/60 animate-ripple" style={{ animationDelay: "0.6s" }} />
              </>
            )}
            <div
              className={cn(
                "text-7xl sm:text-8xl mb-3 transition-transform drop-shadow-lg",
                gameState === "reeling" && "animate-wiggle",
                gameState === "success" && "animate-pop"
              )}
              style={mutationDisplay && gameState === "success" ? { filter: `drop-shadow(${mutationDisplay.glow})` } : {}}
            >
              {fishDisplay}
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white drop-shadow-md">
              {statusText}
            </h2>
            {/* Mutation badge on catch */}
            {mutationDisplay && gameState === "success" && (
              <div
                className="mt-2 px-4 py-1.5 rounded-full text-sm font-bold text-white animate-pop"
                style={{ background: mutationDisplay.color, boxShadow: mutationDisplay.glow }}
              >
                {mutationDisplay.emoji} Мутация: {mutationDisplay.name} ×{mutationDisplay.multiplier}
              </div>
            )}
            {showReelBar && (
              <div className="mt-4 w-full max-w-xs h-3 bg-black/30 rounded-full overflow-hidden">
                <div
                  className="h-full transition-all"
                  style={{
                    width: `${reelProgress}%`,
                    background: "linear-gradient(90deg, #fbbf24, #f97316, #ef4444)",
                  }}
                />
              </div>
            )}
          </div>

          {/* Main action button */}
          <button
            onClick={handleAction}
            disabled={gameState === "casting" || gameState === "waiting" || gameState === "fighting"}
            className="w-full py-4 rounded-2xl text-lg font-black transition-all btn-press disabled:cursor-not-allowed disabled:opacity-60"
            style={{
              background: gameState === "reeling"
                ? "linear-gradient(135deg, #ef4444, #b91c1c)"
                : "linear-gradient(135deg, var(--accent), var(--accent-2))",
              color: "white",
              boxShadow: gameState === "reeling"
                ? "0 8px 24px -8px #ef4444"
                : "0 8px 24px -8px var(--accent)",
            }}
          >
            {gameState === "casting" && "Забрасываем..."}
            {gameState === "waiting" && "Ждём..."}
            {gameState === "reeling" && "🎯 ПОДСЕЧЬ!"}
            {gameState === "fighting" && "Вытаскиваем..."}
            {(gameState === "idle" || gameState === "success" || gameState === "failure") && actionText}
          </button>

          {/* Action grid */}
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 sm:gap-3 mt-6">
            <ActionBtn icon="🛒" label="Магазин" onClick={() => setShowShop(true)} />
            <ActionBtn icon="🎒" label="Инвентарь" onClick={() => setShowInventory(true)} badge={Object.values(inventory).reduce((a, b) => a + b, 0) || undefined} />
            <ActionBtn icon="📋" label="Задания" onClick={() => setShowTasks(true)} badge={task.currentCount >= task.requiredCount ? "!" : undefined} />
            <ActionBtn icon="📖" label="Рыбопедия" onClick={() => setShowPedia(true)} />
            <ActionBtn icon="🧬" label="Мутации" onClick={() => setShowMutations(true)} />
            <ActionBtn icon="✨" label="Обновления" onClick={() => setShowChangelog(true)} />
          </div>
        </main>

        {/* Stats footer */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatCard icon="🐟" label="Уникальных" value={`${uniqueCaughtCount}/${totalUniqueFishCount}`} />
          <StatCard icon="🪝" label="Всего поймано" value={totalCaught} />
          <StatCard icon="💎" label="Стоимость инв." value={inventoryTotalValue} />
          <StatCard icon="🎚️" label="Леска" value={`${tensionLevel}/${tensionMaxLevel}`} />
        </div>
      </div>

      {/* Minigame */}
      {gameState === "fighting" && hookedFish && (
        <Minigame
          fish={hookedFish}
          tensionBonus={tensionLevel * TENSION_UPGRADE_BONUS}
          onResult={handleMinigameEnd}
        />
      )}

      {/* Splash */}
      {showSplash && (
        <div
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center text-white"
          style={{
            background: "linear-gradient(135deg, #4f46e5 0%, #7c3aed 35%, #ec4899 75%, #f59e0b 100%)",
          }}
        >
          <div className="text-9xl animate-float drop-shadow-2xl">🐠</div>
          <h1 className="text-5xl sm:text-6xl font-black mt-6 drop-shadow-lg">Fisch 2 Rod</h1>
          <p className="mt-3 text-lg opacity-90">55 видов · мутации · мифические трофеи</p>
          <button
            onClick={() => setShowSplash(false)}
            className="mt-10 px-10 py-4 rounded-full text-xl font-black bg-white text-indigo-700 shadow-2xl btn-press hover:scale-105 transition-transform"
          >
            🎣 Начать игру
          </button>
        </div>
      )}

      {/* Shop Modal */}
      <Modal open={showShop} onClose={() => setShowShop(false)} title="Магазин" icon="🛒">
        <div className="flex items-center justify-between mb-4">
          <span style={{ color: "var(--text-muted)" }}>Баланс</span>
          <span className="text-xl font-black flex items-center gap-1">💰 {coins}</span>
        </div>
        <div className="rounded-2xl p-5" style={{ background: "var(--surface-soft)" }}>
          <div className="flex items-start gap-3 mb-3">
            <div className="text-3xl">🪢</div>
            <div>
              <h3 className="font-bold text-lg">Прочная леска</h3>
              <p className="text-sm" style={{ color: "var(--text-muted)" }}>Увеличивает зелёную зону в мини-игре</p>
            </div>
          </div>
          <div className="mb-3 flex items-center gap-2">
            {Array.from({ length: tensionMaxLevel }).map((_, i) => (
              <div
                key={i}
                className="flex-1 h-2 rounded-full"
                style={{
                  background: i < tensionLevel ? "linear-gradient(90deg, var(--accent), var(--accent-2))" : "var(--border)",
                }}
              />
            ))}
          </div>
          <button
            onClick={buyTension}
            disabled={tensionLevel >= tensionMaxLevel || coins < tensionCost}
            className="w-full py-3 rounded-xl font-bold text-white btn-press disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              background: tensionLevel >= tensionMaxLevel
                ? "var(--text-muted)"
                : "linear-gradient(135deg, #10b981, #059669)",
            }}
          >
            {tensionLevel >= tensionMaxLevel ? "Максимальный уровень" : `Улучшить — ${tensionCost} 💰`}
          </button>
        </div>

        {/* Mutation info */}
        <div className="rounded-2xl p-5 mt-4" style={{ background: "var(--surface-soft)" }}>
          <div className="flex items-start gap-3 mb-3">
            <div className="text-3xl">🧬</div>
            <div>
              <h3 className="font-bold text-lg">Мутации</h3>
              <p className="text-sm" style={{ color: "var(--text-muted)" }}>
                12% шанс при поимке. Умножают стоимость рыбы!
              </p>
            </div>
          </div>
          <div className="space-y-1.5">
            {mutations.map((m) => (
              <div key={m.id} className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2">
                  <span className="text-lg">{m.emoji}</span>
                  <span className="font-semibold">{m.name}</span>
                </span>
                <span
                  className="px-2 py-0.5 rounded-full text-xs font-bold text-white"
                  style={{ background: m.color }}
                >
                  ×{m.multiplier}
                </span>
              </div>
            ))}
          </div>
        </div>
      </Modal>

      {/* Inventory Modal */}
      <Modal open={showInventory} onClose={() => setShowInventory(false)} title="Инвентарь" icon="🎒">
        <div className="flex items-center justify-between mb-4">
          <span style={{ color: "var(--text-muted)" }}>Общая стоимость</span>
          <span className="text-xl font-black flex items-center gap-1">💰 {inventoryTotalValue}</span>
        </div>
        {Object.keys(inventory).length === 0 ? (
          <div className="text-center py-10" style={{ color: "var(--text-muted)" }}>
            🪣 Инвентарь пуст. Иди ловить!
          </div>
        ) : (
          <div className="space-y-2 mb-4">
            {Object.entries(inventory)
              .sort(([a], [b]) => {
                const fa = parseInvKey(a);
                const fb = parseInvKey(b);
                const fishA = fishData.find((f) => f.name === fa.name);
                const fishB = fishData.find((f) => f.name === fb.name);
                return (rarityOrder.indexOf(fishB?.rarity ?? "common") - rarityOrder.indexOf(fishA?.rarity ?? "common")) ||
                  ((fb.mutation?.multiplier ?? 0) - (fa.mutation?.multiplier ?? 0));
              })
              .map(([key, count]) => {
                const { name, mutation } = parseInvKey(key);
                const fish = fishData.find((f) => f.name === name);
                if (!fish) return null;
                const val = mutation ? fish.value * mutation.multiplier : fish.value;
                return (
                  <div
                    key={key}
                    className="flex items-center justify-between rounded-xl p-3"
                    style={{
                      background: "var(--surface-soft)",
                      boxShadow: mutation ? mutation.glow : "none",
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-3xl" style={mutation ? { filter: `drop-shadow(${mutation.glow})` } : {}}>
                        {fish.emoji}
                      </div>
                      <div>
                        <div className="font-bold flex items-center gap-2">
                          {fish.name}
                          {mutation && (
                            <span
                              className="text-[10px] px-2 py-0.5 rounded-full text-white font-bold"
                              style={{ background: mutation.color }}
                            >
                              {mutation.emoji} {mutation.name}
                            </span>
                          )}
                        </div>
                        <div className="text-sm" style={{ color: "var(--text-muted)" }}>
                          ×{count} · {val} 💰/шт
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => sellOne(key)}
                      className="px-3 py-2 rounded-lg text-sm font-bold text-white btn-press"
                      style={{ background: "linear-gradient(135deg, #0ea5e9, #0284c7)" }}
                    >
                      Продать 1
                    </button>
                  </div>
                );
              })}
          </div>
        )}
        <button
          onClick={sellAll}
          disabled={Object.keys(inventory).length === 0}
          className="w-full py-3 rounded-xl font-bold text-white btn-press disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ background: "linear-gradient(135deg, #ef4444, #dc2626)" }}
        >
          Продать всё
        </button>
      </Modal>

      {/* Tasks Modal */}
      <Modal open={showTasks} onClose={() => setShowTasks(false)} title="Текущее задание" icon="📋">
        <div className="rounded-2xl p-5 mb-4" style={{ background: "var(--surface-soft)" }}>
          <div className="text-sm mb-1" style={{ color: "var(--text-muted)" }}>Цель</div>
          <div className="text-xl font-bold mb-4">Поймать: {task.targetName}</div>
          <div className="flex items-center gap-3 mb-4">
            <div className="flex-1 h-3 rounded-full overflow-hidden" style={{ background: "var(--border)" }}>
              <div
                className="h-full transition-all"
                style={{
                  width: `${Math.min(100, (task.currentCount / task.requiredCount) * 100)}%`,
                  background: "linear-gradient(90deg, var(--accent), var(--accent-2))",
                }}
              />
            </div>
            <span className="font-bold tabular-nums">
              {task.currentCount}/{task.requiredCount}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span style={{ color: "var(--text-muted)" }}>Награда</span>
            <span className="text-lg font-black">💰 {task.reward}</span>
          </div>
        </div>
        <button
          onClick={claimTaskReward}
          disabled={task.currentCount < task.requiredCount}
          className="w-full py-3 rounded-xl font-bold text-white btn-press disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ background: "linear-gradient(135deg, #f59e0b, #ea580c)" }}
        >
          {task.currentCount < task.requiredCount ? "Задание не выполнено" : "🎁 Получить награду"}
        </button>
      </Modal>

      {/* Rybopedia Modal */}
      <Modal open={showPedia} onClose={() => setShowPedia(false)} title="Рыбопедия" icon="📖">
        <div className="flex justify-between mb-4">
          <span style={{ color: "var(--text-muted)" }}>Открыто</span>
          <span className="font-bold">{uniqueCaughtCount}/{totalUniqueFishCount}</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {[...fishData]
            .sort((a, b) => rarityOrder.indexOf(a.rarity) - rarityOrder.indexOf(b.rarity))
            .map((fish) => {
              const isCaught = caughtFish.has(fish.name);
              return (
                <div
                  key={fish.name}
                  className={cn(
                    "rounded-xl p-3 flex flex-col items-center text-center relative",
                    fish.rarity === "legendary" && isCaught && "card-border-legendary",
                    fish.rarity === "mythic" && isCaught && "card-border-mythic"
                  )}
                  style={{ background: "var(--surface-soft)", border: "1px solid var(--border)" }}
                >
                  <div className={cn("text-4xl mb-1", !isCaught && "grayscale opacity-40")}>
                    {isCaught ? fish.emoji : "❓"}
                  </div>
                  <div className="text-xs font-bold truncate w-full">
                    {isCaught ? fish.name : "???"}
                  </div>
                  <div
                    className={cn(
                      "text-[10px] font-bold px-2 py-0.5 rounded-full mt-1",
                      `rarity-${fish.rarity}`
                    )}
                  >
                    {rarityLabels[fish.rarity]}
                  </div>
                  {isCaught && (
                    <div className="text-[10px] mt-0.5" style={{ color: "var(--text-muted)" }}>
                      {fish.value > 0 ? `${fish.value} 💰` : "мусор"}
                    </div>
                  )}
                </div>
              );
            })}
        </div>
      </Modal>

      {/* Mutations Modal */}
      <Modal open={showMutations} onClose={() => setShowMutations(false)} title="Мутации" icon="🧬">
        <div className="text-center mb-4">
          <p className="text-sm" style={{ color: "var(--text-muted)" }}>
            При каждой поимке есть <b>12% шанс</b>, что рыба окажется мутантом!
            Мутация умножает стоимость рыбы и даёт уникальный визуальный эффект.
          </p>
        </div>
        <div className="space-y-3">
          {mutations.map((m) => {
            const count = Object.entries(inventory)
              .filter(([k]) => {
                const { mutation } = parseInvKey(k);
                return mutation?.id === m.id;
              })
              .reduce((sum, [, v]) => sum + v, 0);
            return (
              <div
                key={m.id}
                className="rounded-xl p-4 flex items-center justify-between"
                style={{
                  background: "var(--surface-soft)",
                  boxShadow: m.glow,
                }}
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
                    style={{ background: m.color, boxShadow: m.glow }}
                  >
                    {m.emoji}
                  </div>
                  <div>
                    <div className="font-bold text-lg">{m.name}</div>
                    <div className="text-sm" style={{ color: "var(--text-muted)" }}>
                      В инвентаре: {count} шт
                    </div>
                  </div>
                </div>
                <div
                  className="px-4 py-2 rounded-full text-lg font-black text-white"
                  style={{ background: m.color, boxShadow: m.glow }}
                >
                  ×{m.multiplier}
                </div>
              </div>
            );
          })}
        </div>
        <div
          className="mt-4 rounded-xl p-4 text-center"
          style={{ background: "var(--surface-soft)" }}
        >
          <div className="text-sm" style={{ color: "var(--text-muted)" }}>
            Всего мутантов в инвентаре
          </div>
          <div className="text-3xl font-black mt-1">
            {Object.entries(inventory)
              .filter(([k]) => parseInvKey(k).mutation !== null)
              .reduce((sum, [, v]) => sum + v, 0)}
          </div>
        </div>
      </Modal>

      {/* Changelog Modal */}
      <Modal open={showChangelog} onClose={() => setShowChangelog(false)} title="Список изменений" icon="✨">
        <ul className="space-y-2">
          {changelogData.map((c, i) => (
            <li key={i} className="rounded-xl px-4 py-3" style={{ background: "var(--surface-soft)" }}>
              {c}
            </li>
          ))}
        </ul>
      </Modal>

      {/* Toast */}
      {toast && (
        <div
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[200] px-5 py-3 rounded-full font-bold text-white shadow-2xl animate-pop"
          style={{
            background: toast.kind === "success"
              ? "linear-gradient(135deg, #10b981, #059669)"
              : toast.kind === "fail"
              ? "linear-gradient(135deg, #ef4444, #dc2626)"
              : "linear-gradient(135deg, #3b82f6, #1d4ed8)",
          }}
        >
          {toast.msg}
        </div>
      )}
    </div>
  );
}

function ActionBtn({
  icon, label, onClick, badge,
}: {
  icon: string; label: string; onClick: () => void; badge?: string | number;
}) {
  return (
    <button
      onClick={onClick}
      className="relative glass rounded-xl py-3 px-2 font-semibold transition-all btn-press hover:scale-105"
      style={{ color: "var(--text)", boxShadow: "var(--shadow)" }}
    >
      <div className="text-2xl mb-1">{icon}</div>
      <div className="text-xs sm:text-sm">{label}</div>
      {badge !== undefined && (
        <span
          className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1.5 rounded-full text-xs font-bold flex items-center justify-center text-white"
          style={{ background: "linear-gradient(135deg, #ef4444, #dc2626)" }}
        >
          {badge}
        </span>
      )}
    </button>
  );
}

function StatCard({
  icon, label, value,
}: {
  icon: string; label: string; value: string | number;
}) {
  return (
    <div className="glass rounded-2xl p-4 flex items-center gap-3" style={{ boxShadow: "var(--shadow)" }}>
      <div className="text-3xl">{icon}</div>
      <div>
        <div className="text-xs" style={{ color: "var(--text-muted)" }}>{label}</div>
        <div className="font-black text-lg tabular-nums">{value}</div>
      </div>
    </div>
  );
}
