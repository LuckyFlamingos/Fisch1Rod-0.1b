export type Rarity = "common" | "uncommon" | "rare" | "epic" | "legendary" | "mythic";

export interface Fish {
  name: string;
  emoji: string;
  rarity: Rarity;
  value: number;
  difficulty: { zoneSize: number; speed: number };
}

export interface CaughtFish {
  fish: Fish;
  mutation: Mutation | null;
  key: string; // unique key for inventory: "fishName|mutationId"
}

export interface Mutation {
  id: string;
  name: string;
  emoji: string;
  multiplier: number;
  color: string; // CSS gradient
  glow: string;  // CSS box-shadow
}

export const mutations: Mutation[] = [
  { id: "albino",   name: "Альбинос",   emoji: "🤍", multiplier: 2,  color: "linear-gradient(135deg, #fb7185, #f472b6)", glow: "0 0 20px rgba(251,113,133,0.8)" },
  { id: "giant",    name: "Гигантский", emoji: "🔵", multiplier: 3,  color: "linear-gradient(135deg, #3b82f6, #1d4ed8)", glow: "0 0 20px rgba(59,130,246,0.8)" },
  { id: "neon",     name: "Неоновый",   emoji: "💚", multiplier: 4,  color: "linear-gradient(135deg, #22d3ee, #10b981)", glow: "0 0 20px rgba(34,211,238,0.8)" },
  { id: "golden",   name: "Золотой",    emoji: "💛", multiplier: 5,  color: "linear-gradient(135deg, #fbbf24, #f59e0b)", glow: "0 0 20px rgba(251,191,36,0.8)" },
  { id: "ghost",    name: "Призрачный", emoji: "👻", multiplier: 6,  color: "linear-gradient(135deg, #c4b5fd, #8b5cf6)", glow: "0 0 20px rgba(139,92,246,0.8)" },
  { id: "ancient",  name: "Древний",    emoji: "🔮", multiplier: 8,  color: "linear-gradient(135deg, #f97316, #dc2626)", glow: "0 0 20px rgba(249,115,22,0.8)" },
  { id: "cosmic",   name: "Космический",emoji: "✨", multiplier: 10, color: "linear-gradient(135deg, #ec4899, #8b5cf6, #3b82f6)", glow: "0 0 30px rgba(236,72,153,0.8)" },
];

export const MUTATION_CHANCE = 0.12; // 12%

export function rollMutation(): Mutation | null {
  if (Math.random() > MUTATION_CHANCE) return null;
  // Weighted: common mutations more likely
  const weights = [30, 25, 20, 12, 7, 4, 2];
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < mutations.length; i++) {
    r -= weights[i];
    if (r <= 0) return mutations[i];
  }
  return mutations[0];
}

export const fishData: Fish[] = [
  // Common (10)
  { name: "Карась", emoji: "🐟", rarity: "common", value: 5, difficulty: { zoneSize: 40, speed: 1.5 } },
  { name: "Плотва", emoji: "🐠", rarity: "common", value: 5, difficulty: { zoneSize: 40, speed: 1.5 } },
  { name: "Бычок", emoji: "🐡", rarity: "common", value: 6, difficulty: { zoneSize: 45, speed: 1.3 } },
  { name: "Уклейка", emoji: "🐟", rarity: "common", value: 4, difficulty: { zoneSize: 42, speed: 1.8 } },
  { name: "Пескарь", emoji: "🐟", rarity: "common", value: 5, difficulty: { zoneSize: 40, speed: 1.4 } },
  { name: "Ёрш", emoji: "🐟", rarity: "common", value: 7, difficulty: { zoneSize: 38, speed: 1.6 } },
  { name: "Гольян", emoji: "🐠", rarity: "common", value: 4, difficulty: { zoneSize: 43, speed: 1.9 } },
  { name: "Старый ботинок", emoji: "👢", rarity: "common", value: 3, difficulty: { zoneSize: 50, speed: 1 } },
  { name: "Водоросль", emoji: "🌿", rarity: "common", value: 3, difficulty: { zoneSize: 50, speed: 1 } },
  { name: "Консервная банка", emoji: "🥫", rarity: "common", value: 3, difficulty: { zoneSize: 55, speed: 0.8 } },
  // Uncommon (10)
  { name: "Окунь", emoji: "🐠", rarity: "uncommon", value: 15, difficulty: { zoneSize: 35, speed: 2.0 } },
  { name: "Лещ", emoji: "🐟", rarity: "uncommon", value: 20, difficulty: { zoneSize: 33, speed: 1.9 } },
  { name: "Карп", emoji: "🐟", rarity: "uncommon", value: 25, difficulty: { zoneSize: 30, speed: 2.5 } },
  { name: "Краснопёрка", emoji: "🐠", rarity: "uncommon", value: 18, difficulty: { zoneSize: 35, speed: 2.1 } },
  { name: "Линь", emoji: "🐟", rarity: "uncommon", value: 22, difficulty: { zoneSize: 34, speed: 1.8 } },
  { name: "Язь", emoji: "🐟", rarity: "uncommon", value: 25, difficulty: { zoneSize: 32, speed: 2.2 } },
  { name: "Голавль", emoji: "🐟", rarity: "uncommon", value: 28, difficulty: { zoneSize: 31, speed: 2.4 } },
  { name: "Жерех", emoji: "🐟", rarity: "uncommon", value: 30, difficulty: { zoneSize: 29, speed: 2.8 } },
  { name: "Густера", emoji: "🐠", rarity: "uncommon", value: 15, difficulty: { zoneSize: 36, speed: 1.9 } },
  { name: "Рак", emoji: "🦞", rarity: "uncommon", value: 35, difficulty: { zoneSize: 38, speed: 1.2 } },
  // Rare (10)
  { name: "Щука", emoji: "🐊", rarity: "rare", value: 75, difficulty: { zoneSize: 25, speed: 3.0 } },
  { name: "Судак", emoji: "🐟", rarity: "rare", value: 80, difficulty: { zoneSize: 28, speed: 2.8 } },
  { name: "Сом", emoji: "🐋", rarity: "rare", value: 100, difficulty: { zoneSize: 22, speed: 2.5 } },
  { name: "Налим", emoji: "🐍", rarity: "rare", value: 60, difficulty: { zoneSize: 27, speed: 2.9 } },
  { name: "Форель", emoji: "🐠", rarity: "rare", value: 90, difficulty: { zoneSize: 25, speed: 3.5 } },
  { name: "Хариус", emoji: "🐠", rarity: "rare", value: 85, difficulty: { zoneSize: 26, speed: 3.3 } },
  { name: "Угорь", emoji: "🐍", rarity: "rare", value: 110, difficulty: { zoneSize: 30, speed: 3.1 } },
  { name: "Белый амур", emoji: "🐟", rarity: "rare", value: 95, difficulty: { zoneSize: 24, speed: 2.7 } },
  { name: "Черепаха", emoji: "🐢", rarity: "rare", value: 50, difficulty: { zoneSize: 30, speed: 1.0 } },
  { name: "Пиявка", emoji: "🩸", rarity: "rare", value: 3, difficulty: { zoneSize: 15, speed: 4.0 } },
  // Epic (10)
  { name: "Лосось", emoji: "🍣", rarity: "epic", value: 250, difficulty: { zoneSize: 20, speed: 4.0 } },
  { name: "Осётр", emoji: "🐟", rarity: "epic", value: 300, difficulty: { zoneSize: 18, speed: 3.8 } },
  { name: "Белуга", emoji: "🐋", rarity: "epic", value: 400, difficulty: { zoneSize: 15, speed: 3.5 } },
  { name: "Калуга", emoji: "🐋", rarity: "epic", value: 450, difficulty: { zoneSize: 16, speed: 3.6 } },
  { name: "Таймень", emoji: "🐟", rarity: "epic", value: 350, difficulty: { zoneSize: 17, speed: 4.2 } },
  { name: "Пиранья", emoji: "🐠", rarity: "epic", value: 200, difficulty: { zoneSize: 15, speed: 5.0 } },
  { name: "Золотая рыбка", emoji: "🪙", rarity: "epic", value: 500, difficulty: { zoneSize: 22, speed: 4.5 } },
  { name: "Электрический угорь", emoji: "⚡️", rarity: "epic", value: 333, difficulty: { zoneSize: 17, speed: 4.8 } },
  { name: "Арапаима", emoji: "🦎", rarity: "epic", value: 380, difficulty: { zoneSize: 16, speed: 4.0 } },
  { name: "Рыба-меч", emoji: "⚔️", rarity: "epic", value: 420, difficulty: { zoneSize: 14, speed: 5.2 } },
  // Legendary (8)
  { name: "Морской змей", emoji: "🐉", rarity: "legendary", value: 1000, difficulty: { zoneSize: 12, speed: 5.5 } },
  { name: "Кракен", emoji: "🦑", rarity: "legendary", value: 1200, difficulty: { zoneSize: 10, speed: 5.0 } },
  { name: "Русалка", emoji: "🧜‍♀️", rarity: "legendary", value: 1500, difficulty: { zoneSize: 15, speed: 6.0 } },
  { name: "Лох-несское чудовище", emoji: "🦕", rarity: "legendary", value: 1100, difficulty: { zoneSize: 11, speed: 5.2 } },
  { name: "Ктулху", emoji: "🐙", rarity: "legendary", value: 2000, difficulty: { zoneSize: 8, speed: 6.5 } },
  { name: "Послание в бутылке", emoji: "🍾", rarity: "legendary", value: 3, difficulty: { zoneSize: 25, speed: 0.5 } },
  { name: "Амфитрита", emoji: "👸", rarity: "legendary", value: 1800, difficulty: { zoneSize: 12, speed: 5.8 } },
  { name: "Водяной", emoji: "🧙‍♂️", rarity: "legendary", value: 1300, difficulty: { zoneSize: 13, speed: 5.4 } },
  // Mythic (7)
  { name: "Космический кит", emoji: "🌌", rarity: "mythic", value: 3000, difficulty: { zoneSize: 8, speed: 6.0 } },
  { name: "Феникс-рыба", emoji: "🔥", rarity: "mythic", value: 3500, difficulty: { zoneSize: 7, speed: 6.5 } },
  { name: "Левиафан", emoji: "🐲", rarity: "mythic", value: 4000, difficulty: { zoneSize: 6, speed: 7.0 } },
  { name: "Древний бог", emoji: "👁️", rarity: "mythic", value: 5000, difficulty: { zoneSize: 5, speed: 7.5 } },
  { name: "Зеркальный дракон", emoji: "🪞", rarity: "mythic", value: 2500, difficulty: { zoneSize: 10, speed: 5.8 } },
  { name: "Временной скат", emoji: "⏳", rarity: "mythic", value: 2800, difficulty: { zoneSize: 9, speed: 6.2 } },
  { name: "Пустотный угорь", emoji: "🌀", rarity: "mythic", value: 3200, difficulty: { zoneSize: 7, speed: 7.2 } },
];

// Total: 10+10+10+10+8+7 = 55

export const rarityChances: Record<Rarity, number> = {
  common: 58,
  uncommon: 24,
  rare: 10,
  epic: 4.5,
  legendary: 2.5,
  mythic: 1,
};

export const junkItems = ["👢", "🌿", "🍾", "🥫", "🩸"];

export const rarityLabels: Record<Rarity, string> = {
  common: "Обычная",
  uncommon: "Необычная",
  rare: "Редкая",
  epic: "Эпическая",
  legendary: "Легендарная",
  mythic: "Мифическая",
};

export const rarityOrder: Rarity[] = ["common", "uncommon", "rare", "epic", "legendary", "mythic"];

export const changelogData = [
  "🌟 Новая редкость — Мифическая (7 рыб)",
  "🧬 Система мутаций (12% шанс, 7 типов, множитель до ×10)",
  "🐠 55 видов рыб в коллекции",
  "🎨 Полностью переработан интерфейс",
  "🌗 Темы: Светлая, Тёмная, Океан",
  "📋 Задания, инвентарь, магазин, рыбопедия",
];
